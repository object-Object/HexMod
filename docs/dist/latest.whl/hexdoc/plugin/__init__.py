__all__ = ["hookimpl"]

from pluggy import HookimplMarker

hookimpl = HookimplMarker("hexdoc")
