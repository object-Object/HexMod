from __future__ import annotations

import re
from pathlib import Path
from typing import Annotated, Any, Self

from pydantic import AfterValidator, Field, HttpUrl, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from .cd import RelativePath, RelativePathContext
from .model import StripHiddenModel
from .resource import ResourceDir, ResourceLocation
from .toml_placeholders import load_toml_with_placeholders

NoTrailingSlashHttpUrl = Annotated[
    str,
    HttpUrl,
    AfterValidator(lambda u: str(u).rstrip("/")),
]


class EnvironmentVariableProps(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env")

    # default Actions environment variables
    github_repository: str
    github_sha: str

    # set by CI
    github_pages_url: NoTrailingSlashHttpUrl

    @classmethod
    def model_validate_env(cls):
        return cls.model_validate({})

    @property
    def repo_owner(self):
        return self._github_repository_parts[0]

    @property
    def repo_name(self):
        return self._github_repository_parts[1]

    @property
    def _github_repository_parts(self):
        owner, repo_name = self.github_repository.split("/", maxsplit=1)
        return owner, repo_name


class PatternStubProps(StripHiddenModel):
    path: RelativePath
    regex: re.Pattern[str]
    per_world_value: str | None = "true"


class TemplateProps(StripHiddenModel):
    main: str
    static_dir: RelativePath | None = None
    dirs: list[RelativePath] = Field(default_factory=list)
    packages: list[tuple[str, Path]]
    args: dict[str, Any]

    @field_validator("packages", mode="before")
    def _check_packages(cls, values: Any | list[Any]):
        if not isinstance(values, list):
            return values

        for i, value in enumerate(values):
            if isinstance(value, str):
                values[i] = (value, Path("_templates"))
        return values


class Properties(StripHiddenModel):
    env: EnvironmentVariableProps

    modid: str
    book: ResourceLocation
    default_lang: str
    is_0_black: bool = Field(default=False)
    """If true, the style `$(0)` changes the text color to black; otherwise it resets
    the text color to the default."""

    resource_dirs: list[ResourceDir]
    export_dir: RelativePath | None = None

    pattern_stubs: list[PatternStubProps]

    entry_id_blacklist: set[ResourceLocation] = Field(default_factory=set)

    template: TemplateProps

    @classmethod
    def load(cls, path: Path) -> Self:
        env = EnvironmentVariableProps.model_validate_env()
        return cls.model_validate(
            load_toml_with_placeholders(path) | {"env": env},
            context=RelativePathContext(root=path.parent),
        )

    def mod_loc(self, path: str) -> ResourceLocation:
        """Returns a ResourceLocation with self.modid as the namespace."""
        return ResourceLocation(self.modid, path)

    @property
    def url(self):
        return self.env.github_pages_url
